// script.js

const uploadInput = document.getElementById("upload");
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

const brightnessInput = document.getElementById("brightness");
const contrastInput = document.getElementById("contrast");
const grayscaleInput = document.getElementById("grayscale");
const sepiaInput = document.getElementById("sepia");

const resetButton = document.getElementById("reset");
const downloadButton = document.getElementById("download");

let img = new Image();
let originalImageData;

// Load the uploaded image onto the canvas
uploadInput.addEventListener("change", (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        img.src = e.target.result;

        img.onload = () => {
            canvas.width = img.width;
            canvas.height = img.height;

            ctx.drawImage(img, 0, 0);
            originalImageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        };
    };

    reader.readAsDataURL(file);
});

// Apply filters when sliders are adjusted
function applyFilters() {
    if (!originalImageData) return;

    // Reset the canvas to the original image
    ctx.putImageData(originalImageData, 0, 0);

    // Get the current filter values
    const brightness = brightnessInput.value / 100; // Normalize to [0-2]
    const contrast = contrastInput.value / 100; // Normalize to [0-2]
    const grayscale = grayscaleInput.value / 100; // Normalize to [0-1]
    const sepia = sepiaInput.value / 100; // Normalize to [0-1]

    // Apply CSS filters
    ctx.filter = `
      brightness(${brightness})
      contrast(${contrast})
      grayscale(${grayscale})
      sepia(${sepia})
    `;

    // Redraw the image with filters applied
    ctx.drawImage(img, 0, 0);
}

// Attach event listeners to sliders
[brightnessInput, contrastInput, grayscaleInput, sepiaInput].forEach((slider) => {
    slider.addEventListener("input", applyFilters);
});

// Reset filters to default values
resetButton.addEventListener("click", () => {
    brightnessInput.value = "100";
    contrastInput.value = "100";
    grayscaleInput.value = "0";
    sepiaInput.value = "0";

    applyFilters();
});

// Download the edited image
downloadButton.addEventListener("click", () => {
    const link = document.createElement("a");
    link.download = "edited-image.png";
    link.href = canvas.toDataURL();
    link.click();
});
